import Tilt from 'react-parallax-tilt';

export default function ComplaintCard({ data }) {
  return (
    <Tilt glareEnable={true} glareMaxOpacity={0.3} scale={1.02} transitionSpeed={250}>
      <div className="bg-white p-4 rounded-2xl shadow-lg border-2 border-gray-100">
        <h2 className="text-xl font-semibold">{data.title}</h2>
        <p className="text-gray-600">{data.description}</p>
        <p className="text-sm mt-2">📍 {data.location} | 🏷️ {data.type}</p>
        <p className="text-sm font-bold text-blue-500">Status: {data.status}</p>
      </div>
    </Tilt>
  );
}