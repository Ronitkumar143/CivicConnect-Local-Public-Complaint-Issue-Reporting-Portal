import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ComplaintCard from '../components/ComplaintCard';

export default function Home() {
  const [complaints, setComplaints] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/complaints')
      .then(res => setComplaints(res.data));
  }, []);

  return (
    <div className="grid md:grid-cols-2 gap-4 p-6">
      {complaints.map(c => (
        <ComplaintCard key={c.id} data={c} />
      ))}
    </div>
  );
}