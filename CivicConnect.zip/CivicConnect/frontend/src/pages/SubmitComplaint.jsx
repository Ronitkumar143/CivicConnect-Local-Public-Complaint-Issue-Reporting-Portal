import React, { useState } from 'react';
import axios from 'axios';

export default function SubmitComplaint() {
  const [form, setForm] = useState({ title: '', description: '', type: '', location: '' });

  const handleSubmit = e => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/submit', form)
      .then(res => alert(res.data.message));
  };

  return (
    <form className="max-w-lg mx-auto p-6 shadow-xl bg-white rounded-xl" onSubmit={handleSubmit}>
      <h2 className="text-xl font-bold mb-4">Submit Complaint</h2>
      <input className="input" placeholder="Title" onChange={e => setForm({ ...form, title: e.target.value })} />
      <textarea className="input" placeholder="Description" onChange={e => setForm({ ...form, description: e.target.value })}></textarea>
      <input className="input" placeholder="Type" onChange={e => setForm({ ...form, type: e.target.value })} />
      <input className="input" placeholder="Location" onChange={e => setForm({ ...form, location: e.target.value })} />
      <button type="submit" className="mt-4 bg-blue-500 text-white py-2 px-4 rounded">Submit</button>
    </form>
  );
}
