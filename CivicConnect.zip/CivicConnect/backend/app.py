from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import os

# If extract_features doesn't exist or fails to import, handle it
try:
    from utils.image_preprocess import extract_features
except ImportError:
    def extract_features(_):
        return [0]  # fallback dummy features
    print("⚠️ Warning: extract_features import failed. Using dummy fallback.")

app = Flask(__name__)
CORS(app)

MODEL_PATH = 'model/image_classifier.pkl'
model = None

# Load model safely
if os.path.exists(MODEL_PATH):
    try:
        model = joblib.load(MODEL_PATH)
    except Exception as e:
        print(f"⚠️ Failed to load model: {e}")
else:
    print("⚠️ Model file not found:", MODEL_PATH)

complaints = []
id_counter = 1

@app.route('/api/submit', methods=['POST'])
def submit_complaint():
    global id_counter
    data = request.json
    if not data:
        return jsonify({'error': 'Missing JSON payload'}), 400

    required_fields = ['title', 'description', 'type', 'location']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing field: {field}'}), 400

    complaint = {
        'id': id_counter,
        'title': data['title'],
        'description': data['description'],
        'type': data['type'],
        'location': data['location'],
        'image_url': data.get('image_url', ''),
        'status': 'Submitted'
    }
    complaints.append(complaint)
    id_counter += 1
    return jsonify({'message': 'Complaint submitted successfully!', 'id': complaint['id']}), 200

@app.route('/api/complaints', methods=['GET'])
def get_complaints():
    return jsonify(complaints), 200

@app.route('/api/update_status/<int:cid>', methods=['PUT'])
def update_status(cid):
    data = request.json
    if not data or 'status' not in data:
        return jsonify({'error': 'Missing status in request'}), 400

    for complaint in complaints:
        if complaint['id'] == cid:
            complaint['status'] = data['status']
            return jsonify({'message': 'Status updated!'}), 200
    return jsonify({'message': 'Complaint not found'}), 404

@app.route('/api/predict', methods=['POST'])
def classify_image():
    if not model:
        return jsonify({'error': 'Model not loaded'}), 500

    data = request.json
    if not data or 'image_base64' not in data:
        return jsonify({'error': 'Image data missing'}), 400

    try:
        features = extract_features(data['image_base64'])
        prediction = model.predict([features])
        return jsonify({'predicted_category': prediction[0]}), 200
    except Exception as e:
        return jsonify({'error': f'Prediction failed: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
