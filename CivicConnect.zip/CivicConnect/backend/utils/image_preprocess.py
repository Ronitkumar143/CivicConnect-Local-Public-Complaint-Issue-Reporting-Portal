import base64
import numpy as np
from io import BytesIO
from PIL import Image
from skimage.feature import hog


def extract_features(base64_image):
    image = Image.open(BytesIO(base64.b64decode(base64_image)))
    image = image.convert('L').resize((128, 128))
    image_np = np.array(image)
    features, _ = hog(image_np, pixels_per_cell=(16, 16), cells_per_block=(2, 2), visualize=True)
    return features
